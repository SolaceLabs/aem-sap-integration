import java.util.UUID
def String uuid() {
  return UUID.randomUUID().toString()
}
