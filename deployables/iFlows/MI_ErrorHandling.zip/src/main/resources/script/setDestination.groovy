import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    // e.g. inTopic -> "sap/businesspartner/updated/V1"
    // receiverTopic -> "sap/businesspartner/updated/errors/V1"
    def inTopic = message.getProperty("incomingTopic");
    message.setProperty("receiverTopic", inTopic.replace('/updated/', '/updated/errors/'));
    
    //Debug
    def outTopic = message.getProperty("receiverTopic");
    def messageLog = messageLogFactory.getMessageLog(message);
    
    
    //if (!receiverTopic) {
    //    throw new Exception("receiverTopic not set");
    //}
    
    // Debug log
    messageLog.addAttachmentAsString("Out_Topic_Info", 
        "Source Topic (header.Destination): ${outTopic}", 
        "text/plain");
    
    
    return message;
}