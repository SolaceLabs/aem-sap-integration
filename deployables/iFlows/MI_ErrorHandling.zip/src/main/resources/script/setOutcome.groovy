import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    // 1) Fail fast: tell AEM *not* to retry this failed execution
    message.setProperty("SAP_Retry", false)

    // 2) Read handy context for the log
    def headers = message.getHeaders()
    def httpCode   = (headers?.get("CamelHttpResponseCode") ?: "").toString()
    def reason     = (headers?.get("CamelHttpResponseText") ?: "").toString()
    def ctxId      = (headers?.get("CamelContextId") ?: "").toString()
    def routeId    = (headers?.get("CamelRouteId") ?: "").toString()

    // 3) Console (Trace) log
    println "NO-RETRY MARKER: SAP_Retry=false; HTTP=${httpCode} ${reason}; ctx=${ctxId}; route=${routeId}"

    // 4) Attachment in MPL (Monitor > MPL > Attachments)
    def ml = messageLogFactory.getMessageLog(message)
    if (ml != null) {
        def details = new StringBuilder()
            .append("Marked terminal failure (no retry)\n")
            .append("SAP_Retry: false\n")
            .append("HTTP code: ").append(httpCode).append("\n")
            .append("Reason   : ").append(reason).append("\n")
            .append("ContextId: ").append(ctxId).append("\n")
            .append("RouteId  : ").append(routeId).append("\n")
            .toString()
        ml.addAttachmentAsString("HTTP400 – Terminal (No Retry)", details, "text/plain")
    }

    return message
}