import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def ml = messageLogFactory.getMessageLog(message)
    if (ml != null) {
        // --- Properties ---
        def props = message.getProperties()
        def psb = new StringBuilder("All message properties\n")
        props?.each { k, v -> psb.append("${k} = ${v}\n") }
        ml.addAttachmentAsString("DEBUG – Properties", psb.toString(), "text/plain")

        // Highlight SAP_Retry explicitly
        def sapRetry = props?.get("SAP_Retry")
        ml.addAttachmentAsString("DEBUG – SAP_Retry", "SAP_Retry = ${sapRetry}", "text/plain")

        // --- (Optional) Headers ---
        def headers = message.getHeaders()
        def hsb = new StringBuilder("All message headers\n")
        headers?.each { k, v -> hsb.append("${k} = ${v}\n") }
        ml.addAttachmentAsString("DEBUG – Headers", hsb.toString(), "text/plain")

        // --- (Optional) Response body peek: uncomment if useful ---
        // try {
        //     def bodyStr = message.getBody(java.lang.String)
        //     ml.addAttachmentAsString("DEBUG – Body (first 4KB)", bodyStr?.take(4096), "text/plain")
        // } catch (Exception ignore) { /* may be binary */ }
    }

    // Also echo to trace log (enable Trace in Monitor to see println output)
    println "DEBUG: SAP_Retry=" + message.getProperties()?.get("SAP_Retry")

    return message
}
