import com.sap.gateway.ip.core.customdev.util.Message

Message processData(Message message) {
    def headers = message.getHeaders()

    // Log HTTP status and body to MPL
    def status = headers.get("CamelHttpResponseCode")
    def body = message.getBody(String)
    def messageLog = messageLogFactory.getMessageLog(message)
    if (messageLog != null) {
        messageLog.addAttachmentAsString("HTTP-Status", status as String, "text/plain")
        messageLog.addAttachmentAsString("HTTP-Body", body ?: "<empty>", "text/plain")
    }

    // Mark for DMQ settlement (terminal failure)
    message.setProperty("failedMessageSettlementOutcome", "REJECTED")

    // Throw to stop retries
    throw new Exception("Aborting retries due to HTTP ${status}")
}