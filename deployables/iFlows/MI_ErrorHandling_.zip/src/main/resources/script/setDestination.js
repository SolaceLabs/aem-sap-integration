importClass(com.sap.gateway.ip.core.customdev.util.Message);

function processData(message) {

    // Get body as string
    var body = message.getBody(java.lang.String);
    
    // Parse JSON
    var json = JSON.parse(body);
    
    // Extract fields
    var bpType  = json.original.businessPartnerType ? json.original.businessPartnerType : "";
    var country = json.original.country ? json.original.country : "";
    var city    = json.original.city ? json.original.city : "";
    
    // Concatenate with forward slashes
    var combined = "sap/businesspartner/created/errors/V1/" + bpType + "/" + country + "/" + city;
    
    // Store as single header
    message.setHeader("NewDestination", combined);
    
    return message;
}