import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def code = (message.getHeaders()?.get("CamelHttpResponseCode") ?: "").toString()
    def log = messageLogFactory.getMessageLog(message)

    if (code == "400") {
        message.setProperty("SAP_Retry", false)
        if (log) {
            log.addAttachmentAsString(
                "Exception Handling",
                "HTTP 400 → SAP_Retry=false (send to DMQ)",
                "text/plain"
            )
        }
    } else if (code == "503") {
        if (log) {
            log.addAttachmentAsString(
                "Exception Handling",
                "HTTP 503 → retry allowed",
                "text/plain"
            )
        }
    }

    return message
}
