import com.sap.gateway.ip.core.customdev.util.Message
import java.security.MessageDigest

/* 	This code simply creates a unique id (x-client-id) by which each iFlow can be identified.
	x-client-id is what the backend will use to maintain a per-client retry counter. There
	could be upto 50 separate iFlow instances calling the same backend and the backend will
	use this id to identify each iFlow and how many times each iFlow has retried. Additionally,
	this is a demo setup and we want the exercise/iFlow to end after a specific number of retries!
*/

def Message processData(Message message) {

    // Grab all headers as a Map
    def headers = message.getHeaders()
    
    
    // Read existing Content-Type safely
    def ct = (headers?.get("Content-Type") ?: "").toString().toLowerCase()

    // Ensure Content-Type and Accept are set
    if (!ct.contains("application/json")) {
        message.setHeader("Content-Type", "application/json; charset=UTF-8")
    }
    if (!headers.containsKey("Accept")) {
        message.setHeader("Accept", "application/json")
    }

    // Camel IDs are stable for the life of the deployed artifact and unique per iFlow in the tenant.
    // As such, these are perfect candidates for building a deterministic id (same iFlow → same ID across runs)
    // We will use CamelContextId as the preferred option as it typically maps to the deployed artifact context,
    // but will fallback to CamelRouteId if necessary.
    def ctxId   = (headers?.get("CamelContextId") ?: "").toString()
    def routeId = (headers?.get("CamelRouteId")  ?: "").toString()
    def raw     = ctxId ?: routeId
    if (!raw) raw = "iflow-missing-runtime-id"

    // We hash the camel id to effectively eradicate the possibility of generating the same id for different iFlows.
    // Although the hash is computed each time the flow is invoked, we’ll get the same x-client-id for that iFlow across all messages
    // because the input (CamelContextId / CamelRouteId) is stable for the deployed artifact.
    def md  = MessageDigest.getInstance("SHA-256")
    def hex = md.digest(raw.getBytes("UTF-8")).collect { String.format("%02x", it) }.join()
    def clientId = "rppv2-retry-iflow-" + hex.substring(0, 16)

    // Set the unique client id header
    message.setHeader("X-client-id", clientId)

    return message
}
