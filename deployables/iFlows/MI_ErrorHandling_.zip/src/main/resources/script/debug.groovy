import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {

    def headers = message.getHeaders()

    // Dump all headers (optional)
    headers.each { k, v ->
        println "HDR ${k} = ${v}"
    }

    // Extract Camel runtime IDs
    def ctxId   = (headers?.get("CamelContextId") ?: "").toString()
    def routeId = (headers?.get("CamelRouteId")  ?: "").toString()

    // Log to console/trace
    println "CamelContextId = ${ctxId}"
    println "CamelRouteId  = ${routeId}"

    // Also add an attachment in MPL
    def ml = messageLogFactory.getMessageLog(message)
    if (ml != null) {
        ml.addAttachmentAsString(
            "Camel IDs",
            "CamelContextId = ${ctxId}\nCamelRouteId  = ${routeId}",
            "text/plain"
        )
    }
    
    def messageLog = messageLogFactory.getMessageLog(message);
    
    // Get the topic from the Destination header (set by ContentModifier1)
    def actualTopic = message.getProperty("incomingTopic");
    
    if (!actualTopic) {
        // Fallback: try to get directly from header
        actualTopic = message.getHeaders().get("Destination");
    }
    
    if (!actualTopic) {
        throw new Exception("Destination header not found");
    }
    
    // Store for later use
    message.setProperty("fullIncomingTopic", actualTopic);
    
    // Debug log
    messageLog.addAttachmentAsString("Topic_Info", 
        "Source Topic (header.Destination): ${actualTopic}", 
        "text/plain");

    return message
}
