importClass(com.sap.gateway.ip.core.customdev.util.Message);

function processData(message) {

    // Get body as string
    var body = message.getBody(java.lang.String);
    
    // Parse JSON
    var json = JSON.parse(body);
    
    // Extract fields
    var bpType  = json.businessPartnerType ? json.businessPartnerType : "";
    var country = json.country ? json.country : "";
    var city    = json.city ? json.city : "";
    
    // Concatenate with forward slashes
    var combined = "sap/businesspartner/created/V1/" + bpType + "/" + country + "/" + city;
    
    // Store as single header
    message.setHeader("NewDestination", combined);
    
    return message;
}