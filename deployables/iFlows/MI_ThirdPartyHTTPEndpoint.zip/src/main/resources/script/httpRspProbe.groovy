import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def headers = message.getHeaders()
    def code    = (headers?.get("CamelHttpResponseCode") ?: "").toString()
    def reason  = (headers?.get("CamelHttpResponseText") ?: "").toString()
    def ctxId   = (headers?.get("CamelContextId") ?: "").toString()
    def routeId = (headers?.get("CamelRouteId")  ?: "").toString()

    // Console/trace log (enable Trace log level to see println output)
    println "HTTP PROBE → code=${code}, reason='${reason}', ctx=${ctxId}, route=${routeId}"

    // Optional: peek at response body (comment out if not needed)
    def bodyStr = ""
    try {
        bodyStr = message.getBody(java.lang.String)  // non-destructive read
    } catch (Exception ignore) { /* body may be binary; skip */ }

    // Attachment in MPL for easy inspection
    def ml = messageLogFactory.getMessageLog(message)
    if (ml != null) {
        def details = new StringBuilder()
            .append("HTTP probe after RequestReply\n")
            .append("Response code : ").append(code).append("\n")
            .append("Reason phrase : ").append(reason).append("\n")
            .append("CamelContextId: ").append(ctxId).append("\n")
            .append("CamelRouteId  : ").append(routeId).append("\n")
            .append("\n--- Response Body (first 4KB) ---\n")
            .append(bodyStr?.take(4096))
            .toString()
        ml.addAttachmentAsString("HTTP Probe – After RequestReply", details, "text/plain")
    }

    return message
}
