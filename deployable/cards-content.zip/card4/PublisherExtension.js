sap.ui.define([
    "sap/ui/integration/Extension",
    "./lib/solclient-wrapper"
], function (Extension, SolclientWrapper) {
    "use strict";

    var PublisherExtension = Extension.extend("demo.solace.cards.quickCreateCard.PublisherExtension");

    PublisherExtension.prototype.init = function () {
        Extension.prototype.init.apply(this, arguments);
        this.attachAction(this._handleAction.bind(this));
    }

    PublisherExtension.prototype.onCardReady = function () {
        SolclientWrapper.loadSolclient()
            .then(this._initSession.bind(this));
    };

    /**
     * Initializes and connects to solace.
     * @param {Object} solaceModule
     */
    PublisherExtension.prototype._initSession = function (solaceModule) {
        var params = this.getCard().getCombinedParameters();

        var session = solaceModule.SolclientFactory.createSession(params.solaceConnection);

        this._solaceModule = solaceModule;
        this._session = session;

        try {
            session.connect();
        } catch (error) {
            console.log(error.toString());
        }

        session.on(solaceModule.SessionEventCode.SUBSCRIPTION_ERROR, function (sessionEvent) {
            console.log('Cannot subscribe to topic: ' + sessionEvent.correlationKey);
        });
        session.on(solaceModule.SessionEventCode.SUBSCRIPTION_OK, function (sessionEvent) {
            console.log("Success in subscribing to topic" + sessionEvent);
        });

        session.on(solaceModule.SessionEventCode.UP_NOTICE, function (sessionEvent) {
            console.log("Quick create card for table card Ready to rock and roll Session Connected via UP_NOTICE");
        }.bind(this));

        session.on(solaceModule.SessionEventCode.DISCONNECTED, function (sessionEvent) {
            console.log('Publisher Disconnected.');
            if (session !== null) {
                session.dispose();
                session = null;
            }
        });
    };

    /**
     * Custom event handler for the submit event.
     * Intercepts submit action, performs validation and/or data modifications.
     */
     PublisherExtension.prototype._handleAction = function (oEvent) {
        var solaceModule = this._solaceModule,
            session = this._session,
            card = this.getCard(),
            cardParams = card.getCombinedParameters(),
            publishTopic = cardParams.solaceTopic,
            actionType = oEvent.getParameter("type"),
            formData = oEvent.getParameter("parameters").data;

        if (actionType !== "Submit") {
            return;
        }

        oEvent.preventDefault();

        // Validation
        if (!card.validateControls()) {
            return;
        }

        if (session === null) {
            console.log('Cannot publish because not connected to Solace message router.');
            return;
        }

        var messagePayload = {
            "NotifNumber": formData.notifNumber,
            "NotifType": formData.notifType.value,
            "NotifCategory": formData.notifCategory.value,
            "Priority": formData.priority.value,
            "ProblemDesc": formData.comment,
            "FunctLocat": formData.funcLocation.value,
            "ContactPerson": formData.contactPerson
        };

        // @todo uncomment if table card can work with subtopics
        // publishTopic = publishTopic + "/" + messagePayload["Priority"];

        var message = solaceModule.SolclientFactory.createMessage();
        message.setDestination(solaceModule.SolclientFactory.createTopicDestination(publishTopic));
        message.setBinaryAttachment(JSON.stringify(messagePayload));
        message.setDeliveryMode(solaceModule.MessageDeliveryModeType.DIRECT);

        console.log('Publishing message "' + messagePayload + '" to topic "' + publishTopic + '"...');
        console.log ("Selected notifType is " + formData.notifType.value);

        try {
            session.send(message);
            console.log('Message published.');
        } catch (error) {
            console.log(error.toString());
        }
    };

    return PublisherExtension;
});