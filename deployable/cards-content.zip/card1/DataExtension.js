sap.ui.define([
    "sap/ui/integration/Extension",
    "./lib/solclient-wrapper"
], function (Extension, SolclientWrapper) {
    "use strict";
    var DataExtension = Extension.extend("demo.solace.cards.listCard.DataExtension");

    /**
     * Connects to solace when the card is initialized
     */
    DataExtension.prototype.onCardReady = function () {
        this._data = [];

        // Load the solace client library
        SolclientWrapper.loadSolclient()
            .then(this._initSession.bind(this));
    };

    /**
     * Initializes and connects to solace.
     * @param {Object} solaceModule
     */
    DataExtension.prototype._initSession = function (solaceModule) {
        var params = this.getCard().getCombinedParameters();

        var session = solaceModule.SolclientFactory.createSession(params.solaceConnection);

        try {
            session.connect();
        } catch (error) {
            console.log(error.toString());
        }

        session.on(solaceModule.SessionEventCode.SUBSCRIPTION_ERROR, function (sessionEvent) {
            console.log('Cannot subscribe to topic: ' + sessionEvent.correlationKey);
        });
        session.on(solaceModule.SessionEventCode.SUBSCRIPTION_OK, function (sessionEvent) {
            console.log("Success in subscribing to topic" + sessionEvent);
        });

        session.on(solaceModule.SessionEventCode.MESSAGE, this._messageReceived.bind(this));

        session.on(solaceModule.SessionEventCode.UP_NOTICE, function (sessionEvent) {
            console.log("List Card Ready to rock and roll Session Connected via UP_NOTICE");
            this._subscribe(params.solaceTopic + "/All");
        }.bind(this));

        this._solaceModule = solaceModule;
        this._session = session;
    };

    /**
     * Subscribes to the given topic.
     * @param {Object} solaceModule
     * @param {Object} session
     * @param {string} topic
     */
    DataExtension.prototype._subscribe = function (topic) {
        var session = this._session,
            solaceModule = this._solaceModule;


        // @todo first version is if table card is configured to work with subtopics, second if not
        // topic = topic.replace("/All", "/*"); // uncomment if table works with subtopics
        topic = topic.replace("/All", "");

        var solTopic = solaceModule.SolclientFactory.createTopic(topic);

        try {
            solTopic.validate()
        } catch (error) {
            console.log("List Card Topic Failed validation" + error);
        }

        try {
            session.subscribe(solTopic, true, topic, 10000);
            this._sessionSubscribedTopic = solTopic;
        } catch (error) {
            console.log("List Card " + error.toString());
        }
    };

    /**
     * Callback when a new message is received
     * @param {Object} message
     */
    DataExtension.prototype._messageReceived = function (message) {
        console.log('List Card Received message: "' + message.getBinaryAttachment() + '", details:\n' + message.dump());

        var newNotification = JSON.parse(message.getBinaryAttachment());

        this._data.unshift(newNotification);

        this.getCard().getModel().setProperty("/", this._data);
    };

    /**
     * Called when the filter is changed.
     * @param {string} filterValue
     * @returns {array}
     */
    DataExtension.prototype.updateFilter = function (filterValue) {
        var params = this.getCard().getCombinedParameters();

        if (!this._sessionSubscribedTopic) {
            // no subscription yet
            return Promise.resolve(this._data);
        }

        this._session.unsubscribe(this._sessionSubscribedTopic);

        this._subscribe(params.solaceTopic + "/" + filterValue);
        this._data = [];

        return Promise.resolve(this._data);
    };

    return DataExtension;
}
);