importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);
function processData(message) {
       var body = String(message.getBody( new java.lang.String().getClass()));
       //create json from string object
       body = JSON.parse(body);
       
       var orderHeader = body.orderHeader;
       var emailAddress = orderHeader[0].customer[0].emailAddress[0];
       //var email = emailAddress[email];
       const messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null){
        messageLog.setStringProperty("JS Logger", "Logger")
     //   messageLog.addAttachmentAsString("JavaScript Object", JSON.stringify(body), "text/plain");
     messageLog.addAttachmentAsString("JavaScript Object",emailAddress.email, "text/plain");
     }

return message;
}


