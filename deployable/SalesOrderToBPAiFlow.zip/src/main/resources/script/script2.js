/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
  var body = String(message.getBody(new java.lang.String().getClass()));
  var jsonPayload = JSON.parse(body);

  var orderHeader = jsonPayload.orderHeader;
  orderHeader.forEach(function (order) {
    if (order.date) {
      // Check if the date is in string format (yyyy-MM-dd)
      if (typeof order.date === 'string') {
        var dateParts = order.date.split("-");
        var dateObject = new Date(dateParts[0], dateParts[1] - 1, dateParts[2]);
        order.date = dateObject.getTime() / 1000; // Convert to seconds since epoch
      } else if (typeof order.date === 'number') {
        // Assume the date is already in epoch format (no conversion needed)
        // You can add additional handling here if necessary
      }
    }
  });

  message.setBody(JSON.stringify(jsonPayload));
  return message;
}


