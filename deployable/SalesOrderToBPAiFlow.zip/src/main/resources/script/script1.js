/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function convertDateToEpoch(payload) {
  try {
    const jsonPayload = JSON.parse(payload);
    const orderHeader = jsonPayload.orderHeader;

    // Iterate through the orderHeader array
    orderHeader.forEach((order) => {
      if (order.date) {
        // Convert the date string to epoch format
        const dateParts = order.date.split('-');
        const dateObject = new Date(dateParts[0], dateParts[1] - 1, dateParts[2]);
        order.date = dateObject.getTime() / 1000; // Convert to seconds since epoch
      }
    });

    // Convert the modified payload back to JSON
    const updatedPayload = JSON.stringify(jsonPayload);
    return updatedPayload;
  } catch (error) {
    console.error('Error converting date to epoch:', error);
    return null;
  }
}