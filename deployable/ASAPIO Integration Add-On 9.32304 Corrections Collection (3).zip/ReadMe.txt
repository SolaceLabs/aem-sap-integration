------------------------------------------------------------------------
|Manual Activity                                                       |
------------------------------------------------------------------------
|VALID FOR |
|Software Component ASANWEE |
| Release 100 SAPK-10007INASANWEE - SAPK-10007INASANWEE |
------------------------------------------------------------------------

# Object list of non-supported objects for note 0003334986:

# REPT /ASADEV/ACI_QUICK_VIEWS


################################################################
Step 1: Go to transaction code SE38
-> Enter /ASADEV/ACI_QUICK_VIEWS
-> Click on Change button
Step 2: Goto -> Text elements -> Text Symbols -> Press Insert line button (+) and enter the following text:
Text Number:I01
Text:The Transport Request has been created with number &
Save and activate.
Step 3: Goto -> Translation
Original Language: EN
Target Language: DE
Then scroll down and find the text we already created I01 which is highlighted with red color and add this text:
Der Transportauftrag wurde mit der Nummer & erstellt